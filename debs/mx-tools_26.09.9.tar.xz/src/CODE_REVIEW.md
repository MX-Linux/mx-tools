# MX Tools — Code Review

Scope: `src/`, `qml/`, `tests/`, `CMakeLists.txt`, `build.sh`, `debian/rules`, `debian/install`, `PKGBUILD`, `.github/workflows/ci.yaml`, `.gitignore`. `release.sh` and translation contents were not reviewed, apart from the numerus forms noted in item 21.

Checks run during the review:

- Built with `-Wall -Wextra -Wshadow` (Qt 6.8.2, GCC 14.2): no warnings, `ctest` passes.
- `cmake -DUSE_CLANG=ON`: original review inferred GCC from the cache; generated commands use clang++ (see validation on item 30).
- Read the xfconf-query source (`xfconf-query/main.c`): the output strings that `toolmodel.cpp` parses are localized.

Items are ordered by severity within each section. Line references point to the current tree.

## Validation by Codex (2026-09-23)

Checked all 44 items against the working tree. **INVALID** marks a disproved finding; **PARTLY INVALID** preserves a real concern but rejects specific claims; **UNVERIFIED** and **DESIGN PREFERENCE** are not confirmed defects. Original text is retained below for context. Unannotated items remain plausible findings, not a claim that every runtime scenario was reproduced.

- **Invalid:** 19 (removed).
- **Partly invalid / overstated:** 12, 24, 30, 31, 32, 36.
- **Needs runtime evidence:** 22, 44.
- **Design preference, not an established bug:** 29; the refactors in 23 and 43 are also design suggestions unless accompanied by a concrete failure.
- Evidence: an offscreen Qt 6.8.2 QML probe with an 18-point application font reported `Application.font.pixelSize == 24` and `Button.font.pixelSize == 24`; a default interactive GridView reported `keyNavigationEnabled == true`. A fresh `cmake -DUSE_CLANG=ON` configuration identified GNU and cached `/usr/bin/c++`, but its generated Ninja compile/link commands actually used `clang++`.

Verification: `./build.sh` was blocked by the existing build cache referencing missing `/usr/sbin/ninja`; a fresh Release configure/build in `/tmp/mx-review-build` succeeded and CTest passed (1/1). Only this review document was intentionally edited; application fixes were not part of this validation. The document is ignored by the user's global Git ignore rules.

## Menu visibility / Whisker Menu integration (high)

1. [x] **Parsing Whisker favorites fails in non-English locales.** `readXfconfArray` checks for `"Value is an array"` (`src/toolmodel.cpp:275`) and `"does not exist"` (`:268`). Both strings are gettext-translated in xfconf-query (`main.c:709`, `main.c:744`). With a localized `LANG`, the function returns `nullopt`, `snapshotWhiskerMenuFavorites` stores an empty list, and `reconcileOneWhiskerMenuArray` skips the restore. Favorites that Whisker drops while tools are hidden are never restored.
   **Fix:** start xfconf-query with `LC_ALL=C` (`QProcess::setProcessEnvironment`). Detect a missing property from the exit code or `-l` output, not from message text.

2. [x] **stderr is parsed as favorites.** `runXfconfQuery` appends stderr to stdout (`:228`). `readXfconfArray` then treats every non-empty line after the header as an array item (`:280-284`). Any GLib/D-Bus warning becomes a bogus favorite, and `writeXfconfArray` writes it back into the panel config.
   **Fix:** keep stdout and stderr separate. Parse only stdout.

3. [x] **Rewriting the favorites array isn't atomic, and failures are ignored.** `writeXfconfArray` resets the property with `-r` and ignores the result (`:292-293`), then re-creates it with `-n` (`:298-304`). If the create fails or hits the 3 s timeout, the user's favorites are gone. `reconcileWhiskerMenuFavorites` returns `void`, and `restoreMenuEntries` then runs `state.clear()` (`:870-872`), which deletes the only snapshot.
   **Fix:** set the array in place where xfconf-query allows it. Check every step. Return a result up to `restoreMenuEntries`, and keep the state file when reconciliation fails.

4. [x] **The switch can show the wrong state after a failure.** `ModernSwitch` flips its own `checked` value. It only re-syncs from `backend.hideFromMenu` when `hideFromMenuChanged` fires. `setHideFromMenu` emits that signal on lock failure (`:459`) but not on these failure paths:
   - `mkpath` failure (`:449-451`)
   - `hideMenuEntries` failing and then rolling back successfully (`:824-826` → `:472-473`)
   - `restoreMenuEntries` or `restoreLegacyMenuEntries` failing (`:471-473`)

   On all of these, the switch ends up showing the opposite of the real state.
   **Fix:** emit `hideFromMenuChanged` on every exit path of `setHideFromMenu` (one exit point or a scope guard), or re-bind `checked` in QML after `onToggled`.

5. [x] **Menu operations block the GUI thread.** `setHideFromMenu` runs synchronously:
   - `discoverWhiskerMenuInstances` starts one xfconf-query for the list, plus one per panel plugin (`:248`), each with a 3 s timeout.
   - `reconcileWhiskerMenuFavorites` repeats the plugin type check for each instance (`:970-976`), duplicating the discovery code.
   - Each desktop file is written atomically.

   A typical panel means dozens of process spawns before the UI repaints. If xfconfd hangs, the UI can freeze for minutes.
   **Fix:** fetch all plugin types in one call (`xfconf-query -c xfce4-panel -lv`) and share that between discovery and reconciliation. Run the operation off the GUI thread (async `QProcess` or `QtConcurrent`). Expose a `busy` property so QML can disable both switches meanwhile.

6. [x] **Tools installed after hiding still show in the menu.** The hidden set is the snapshot of `m_menuFiles` taken at hide time (`:789`). On startup, `detectMenuVisibility` only reads `active` (`:744`). A later MX tool package appears in the system menu while the switch says "hidden", and restore doesn't know about it.
   **Fix:** when the state is active at startup, take the operation lock, hide newly discovered entries, and record them in the state file.

7. [x] **User overrides ignore `XDG_DATA_HOME`.** `userApplicationsPath` is hard-coded as `~/.local/share/applications` (`:33`, used at `:751`, `:772`, `:883`). With `XDG_DATA_HOME` set, menus read overrides from a different directory, so hiding silently does nothing.
   **Fix:** write new overrides to `QStandardPaths::writableLocation(QStandardPaths::ApplicationsLocation)`. Keep the `$HOME` path only for legacy detection, since old releases wrote there.

8. [x] **Fallback icon path is wrong on Qt < 6.5.** `fallbackIcon()` always uses `:/qt/qml/MxTools/icons/logo.svg` (`:661`). `main.cpp:48-52` and the QTP0001 handling in CMake show that the prefix is `:/MxTools/` on Qt < 6.5 (Bookworm; also Ubuntu 24.04 in CI). There, the last-resort icon is null and tools without an icon render as transparent squares.
   **Fix:** define the resource path once (a CMake-provided definition or a shared header constant) and use it in both places.

## C++ correctness (medium)

9. [x] **Desktop files are parsed with regexes over the whole file.**
   - `value()` (`:568-573`) returns the first `Key=` it finds anywhere, not only in `[Desktop Entry]`. A `[Desktop Action …]` group can supply `Name`/`Icon`/`Exec`/`Comment` when the main group lacks the key.
   - `Key = value` spacing and the spec's escapes (`\s`, `\n`, `\t`, `\\`) aren't handled.
   - `value()` is case-sensitive but `listValue()` isn't (`:110`).
   - A new `QRegularExpression` is compiled for every key of every file.

   **Fix:** add one small parser that returns the `[Desktop Entry]` group as a `QHash` (including localized keys). Use it for discovery, filtering and the visibility code.

10. [x] **`MX-OnlyLive` / `MX-OnlyInstalled` use a substring match.** `visibleInCurrentEnvironment` calls `text.contains(...)` on the whole file (`:614-615`). A mention in `Keywords`/`Comment`, or `MX-OnlyLive=false`, excludes the tool. Separately, `mx-remastercc.desktop` and `live-kernel-updater.desktop` are special-cased in code (`:498-501`), which duplicates what `MX-OnlyLive` is meant to express.
    **Fix:** check the parsed key or the exact `Categories` token (whichever the MX convention is). Move the hard-coded exclusions into the desktop files, or at least into a named constant.

11. [x] **Tools with several MX categories are listed twice.** `desktopFilesForCategory` runs once per category (`:486`). A file with `Categories=X-MX-Setup;X-MX-Utilities;` produces two `ToolInfo` entries. "All tools" and search results then show duplicates, and `totalCount` is too high.
    **Fix:** decide the intended behavior. Probably one `ToolInfo` per file, with a primary display category and a list of member categories for filtering.

12. [x] **Search matches the untrimmed text and needs an exact phrase.** `refilter` checks emptiness on `m_search.trimmed()` but matches the untrimmed `m_search` (`:556-560`), so a trailing space ("backup ") empties the results. Multi-word queries must appear as one contiguous substring of the joined search text.
   **Validation — PARTLY INVALID:** The missing trim is real, but a trailing space does not necessarily empty results: searchText joins names, comments, keywords and categories with spaces, so "backup " can match "Backup Tool". Contiguous phrase matching is the implemented search policy, not independently a bug without a term-search requirement.

    **Fix:** trim once outside the loop, split on whitespace, and require every term to match.

13. [x] **The "already running" check relies on bare PIDs.** `launch()` stores the PID from `startDetached` (`:695`). `isProcessRunning` only checks `/proc/<pid>/stat` (`:74-87`). If an unrelated process reuses the PID after the tool exits, MX Tools refuses to launch that tool until it is restarted. Launchers that fork (for example via `pkexec`) and exit immediately make the check ineffective anyway.
    **Fix:** store the process start time (field 22 of `stat`) with the PID and compare both. Or drop the check where the tools already enforce a single instance.

14. [x] **Sorting isn't locale-aware.** `std::ranges::sort(categoryTools, {}, &ToolInfo::name)` (`:540`) compares UTF-16 code units, so accented or lower-case translated names sort after "Z".
    **Fix:** sort with `QCollator` (case-insensitive, numeric mode).

15. [x] **An empty `Icon=` resolves to a directory.** With an empty `iconName`, the candidate is `root + ""` (`:645`). `QFile::exists(directory)` returns true, so `lookupIcon` returns a null `QIcon(directory)` instead of `nullopt`. This only works because `requestPixmap` falls back afterwards.
    **Fix:** return `nullopt` early for empty names, and use `QFileInfo::isFile()`.

16. [x] **Desktop IDs are wrong for files in subdirectories.** Discovery recurses (`:595`), but the code derives desktop IDs with `QFileInfo::fileName()` (`:790`, `:886`, `:958`). Per the spec, `applications/foo/bar.desktop` has the ID `foo-bar.desktop`. The override is written under a name that does nothing, and files with the same basename collide. Discovery also ignores `XDG_DATA_DIRS` (for example `/usr/local/share/applications`).
    **Fix:** compute IDs relative to the applications root, replacing `/` with `-`, or stop recursing. If desktop-ID handling is reworked, consider scanning `XDG_DATA_DIRS` too.

17. [x] **`openChangelog` can block for up to 30 s.** It runs `zcat` with the default `waitForFinished()` timeout on the GUI thread (`:729-731`).
    **Fix:** use an asynchronous `QProcess` and emit `documentReady` from `finished`.

18. [x] **Exec field-code handling is incomplete.** `tool.exec.remove(" %[a-zA-Z]")` (`:523`) leaves `%%` unescaped. `QProcess::splitCommand` quoting also differs from the Desktop Entry spec (backslash escapes inside quotes). Low risk, since MX controls these files; fold it into the parser from item 9.

## QML / UI (medium)

20. [x] **The whole model resets on every keystroke.** `refilter` always calls `beginResetModel`/`endResetModel` (`:551`, `:565`). The GridView recreates every delegate and loses the current index and keyboard focus. The `displaced` transition (`Main.qml:476-478`) never runs, because a reset produces no displacement. `setSelectedCategory` also refilters while a search is active, although the category is ignored then (`:556`).
    **Fix:** use a `QSortFilterProxyModel` over a static source model, or emit row insert/remove changes. Skip the category refilter while the search is non-empty.

21. [x] **English shows "N tool(s)" literally.** `qsTr("%n tool(s)", "", toolsGrid.count)` (`Main.qml:359`) needs numerus forms, but there is no English catalog: `translations/mx-tools_en_US.ts` doesn't exist and `CMakeLists.txt:141` excludes it. In `mx-tools_fr.ts:103` and `mx-tools_fr_BE.ts:103`, the singular form is hard-coded as `1 outil`. French uses the singular form for 0, so an empty result reads "1 outil".
    **Fix:** add a built `en_US` catalog with numerus forms (remove the exclusion), and change the French forms to `%n outil`.

22. [x] **Keyboard navigation of the grid is likely incomplete (not verified).** Cards are focusable Buttons inside a virtualized GridView. Tab moves between instantiated delegates, but nothing scrolls the view to the focused card, and there is no arrow-key navigation (`currentIndex` isn't used). Verify manually.
   **Validation — UNVERIFIED / PARTLY INVALID:** GridView already defaults keyNavigationEnabled to interactive (true here); the Qt 6.8.2 probe confirmed true without setting it. GridView is already a focus scope. Absence of explicit currentIndex usage does not establish absence of built-in arrow navigation. The actual focus path through the Button delegates and scrolling on Tab still need an interactive reproduction; merely enabling keyNavigationEnabled is not a demonstrated fix.

    **Fix:** make the GridView the focus scope with `keyNavigationEnabled`, a `currentIndex` highlight, and Enter launching the current card. Alternatively, call `positionViewAtIndex` when a delegate gets `activeFocus`.

23. [ ] **Categories are identified by their translated names.** `m_selectedCategory`, `ToolInfo::category` and the "All tools" sentinel (`m_categories[0]`) are all translated strings (`:482`, `:553-558`). QML repeats `qsTr("All tools")` (`Main.qml:342`).
   **Validation — DESIGN SUGGESTION:** Stable category IDs are a reasonable robustness improvement, but translated strings are used consistently within the backend today. A concrete collision or mismatched translation is needed to demonstrate incorrect filtering; duplicating the display label in QML alone does not establish that failure.

    **Fix:** expose stable IDs (`Live`, `Setup`, …) alongside display names, with an empty ID meaning "all". Select and filter by ID.

24. [x] **Theme colors are passed redundantly.** The default colors of `ToolCard`, `ModernSwitch`, `SecondaryButton` and `CategoryButton` already equal `Main.qml`'s palette values. Every call site still passes `accentColor`, `hoverColor`, `borderColor`, `knobColor`, `knobBorderColor` and `inactiveColor` again (for example `Main.qml:264-267`, `382-385`, `412-415`, `512-515`, and nine `SecondaryButton` sites). Each delegate also creates its own `SystemPalette`.
   **Validation — PARTLY INVALID:** The palettes are not always equivalent. Main.qml explicitly selects Active or Inactive according to root.active, whereas component-local SystemPalette objects do not bind to root.active. CategoryButton also defaults mutedTextColor to full systemPalette.text, while Main passes the 0.82-alpha secondaryTextColor. Removing overrides mechanically changes appearance. A shared theme may be a useful refactor if it preserves these semantics.

    **Fix:** add one `Theme` singleton (`pragma Singleton`, registered in `qt6_add_qml_module`), use it inside the components, and delete the call-site overrides.

25. [x] **Large QML blocks are duplicated.** The menu-visibility label, switch and tooltip appear twice (`Main.qml:242-275`, `492-523`). The category Repeater also appears twice (`:214-232`, `:311-330`). Clicking a label doesn't toggle its switch.
    **Fix:** extract a `MenuVisibilityToggle.qml` component (label and switch as one control, with a clickable label) and a category list component that takes an orientation.

26. [x] **The error dialog has no width limit, and errors overwrite each other.** `errorDialog` (`Main.qml:621-644`) has wrapping text but no width, so a long path produces a very wide dialog. A second error replaces the first before it has been read.
    **Fix:** set `width: Math.min(root.width - 80, 480)`. Queue messages if multiple errors are possible.

27. [x] **Restored window position can be off-screen.** `Settings` persists `x`/`y` (`Main.qml:41-42`). After the monitor layout changes, the window can open off-screen, and on Wayland `x`/`y` have no effect.
    **Fix:** clamp to `Screen.desktopAvailableWidth`/`desktopAvailableHeight` at startup, or persist only size and maximized state.

28. [x] **The search glyph may render as a missing-glyph box.** `"⌕"` (U+2315, `Main.qml:131`) is missing from many fonts.
    **Fix:** use a theme icon (`edit-find` / `system-search`).

29. [ ] **Escape quits the app when the search field is empty** (`Main.qml:694`). This is surprising. Use `StandardKey.Quit` for quitting and keep Escape only for clearing the search.
   **Validation — DESIGN PREFERENCE:** The source explicitly implements Escape-to-close when search is empty. No requirement or failing workflow establishes that behavior as a bug. Changing it needs a product decision, not a correctness fix.


## Build, packaging, repository

30. [x] **`--clang` / `USE_CLANG` doesn't switch compilers.** `CMakeLists.txt:92-97` sets `CMAKE_CXX_COMPILER` after `project()`. Verified: `cmake -DUSE_CLANG=ON` reports `CXX compiler identification is GNU 14.2.0` and caches `/usr/bin/c++`. It also overwrites `CMAKE_CXX_COMPILER_ID` with `Clang`, so GCC is invoked with `-flto=thin` and `-Werror=return-stack-address`.
   **Validation — PARTLY INVALID:** Setting the compiler after project() is indeed unsafe, but the stated consequence is incorrect. A fresh configuration caches /usr/bin/c++ and detects GNU, while generated CMakeFiles/rules.ninja actually invokes clang++ for compilation and linking. The failure is inconsistent compiler detection/toolchain metadata, not proof that GCC receives the Clang flags. Keep the recommendation to choose the compiler before project().

    **Fix:** remove `USE_CLANG`. In `build.sh`, pass `-DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++` (as CI already does), and branch on the real `CMAKE_CXX_COMPILER_ID`.

31. [x] **Warnings aren't strict.** Only `-Wpedantic` plus a few `-Werror=` options are enabled. The code builds cleanly with `-Wall -Wextra -Wshadow` today (verified), so add them. `-Wconversion` would flag `qsizetype`→`int` narrowing, starting at `toolmodel.cpp:81`. The flag list is also copied between `mx-tools` and `test-toolmodel`.
   **Validation — PARTLY INVALID:** Both targets already specify blanket -Werror in addition to the listed selective -Werror flags. Missing -Wall/-Wextra is a valid warning-coverage improvement, but the claim that only -Wpedantic and a few selective -Werror options are enabled omits the existing warnings-as-errors policy.

    **Fix:** add the flags and share one list (a CMake function or an `INTERFACE` target).

32. [ ] **`toolmodel.cpp` is compiled twice, with test-only code in production.** The test target recompiles `src/toolmodel.cpp` (`CMakeLists.txt:252-256`) with `MX_TOOLS_APPLICATIONS_PATH` and `MX_TOOLS_TESTING`, and the production source carries an `#ifdef` for tests (`toolmodel.cpp:61-69`).
   **Validation — PARTLY INVALID:** The source is compiled twice, but the test-only environment override is guarded by #ifdef MX_TOOLS_TESTING and that definition is supplied only to test-toolmodel. It is absent from the production binary. Sharing a library or injecting dependencies is an optional architecture/testability refactor, not a fix for test-only code shipping in production.

    **Fix:** build `ToolModel` as a static or OBJECT library. Inject the applications root and the live/installed state at runtime (constructor parameters), so tests exercise the same code that ships.

33. [x] **Release flags are hand-rolled.** `-Os`, `NDEBUG` and LTO flags are added manually on top of CMake's Release defaults (`:214-226`). `-fdiagnostics-color=always` (`:84`) puts ANSI escape codes into Debian/OBS build logs. `QT_DEPRECATED_WARNINGS` does nothing in Qt 6.
    **Fix:** use `CMAKE_INTERPROCEDURAL_OPTIMIZATION` together with `check_ipo_supported`. Use `CMAKE_COLOR_DIAGNOSTICS` (CMake ≥ 3.24) or leave color off. Drop the dead define.

34. [x] **Install rules are duplicated for each packager.** CMake installs only the binary (`:247`). `debian/install` and `PKGBUILD` list the other assets separately, and they have already drifted: commit a609e0d is "Install the man page that was silently dropped". `PKGBUILD:40` and `:62` hide failures with `2>/dev/null || true`, so missing `.qm` files or man pages ship without an error.
    **Fix:** install every asset from CMake (`GNUInstallDirs`) and have both packagers use `cmake --install` / `dh_auto_install`. Remove `|| true`.

35. [x] **`PKGBUILD` builds from the working tree.** It has an empty `source=()`, runs `cd "${startdir}"` and then `rm -rf build` (`PKGBUILD:11-18`). That deletes the developer's build directory and makes builds non-reproducible. There are separate root and `arch/` PKGBUILDs (plus an untracked `aur/`) that can drift, and `license=('GPL3')` should be the SPDX identifier `GPL-3.0-or-later`.
    **Fix:** build from a tarball in `$srcdir`, keep a single maintained PKGBUILD, and use the SPDX identifier.

36. [x] **CI never runs the tests or loads the QML.** `ci.yaml:55-56` only builds; the tests run only through `dh_auto_test` in the Debian canary job. Ubuntu 24.04 (Qt 6.4) is the only Qt < 6.5 coverage, and QML is never loaded there.
   **Validation — PARTLY INVALID:** The build-test job does not execute CTest, but CI as a whole does: debian-package-check invokes debuild and debian/rules leaves dh_auto_test enabled. Thus the heading "CI never runs the tests" is false (as the body itself acknowledges). Running tests in both compiler jobs and adding QML runtime coverage remain valid recommendations. ubuntu-latest also does not pin Ubuntu 24.04 permanently.

    **Fix:** add `ctest --test-dir build --output-on-failure`. Add a smoke test that loads `Main` with `QT_QPA_PLATFORM=offscreen` against a stub backend and fails on warnings, plus the `all_qmllint` target from `qt_add_qml_module`.

37. [x] **`.gitignore` hides files the translation workflows need.**
    - `Makefile*` ignores `translations-desktop-file/Makefile`, which the readme requires (`make desktop`, `translations-desktop-file/readme:21`). It is untracked, so a fresh clone can't run that workflow.
    - `.tx/` ignores the Transifex config used by `tx pull` in `translations/get_translations`. Credentials live in `~/.transifexrc`, not in `.tx/config`.
    - The unanchored `mx-tools` pattern ignores any path with that name.

    **Fix:** anchor the patterns, and track the Makefile and `.tx/config`.

38. [x] **Translations load only from the installed path.** `main.cpp:68` hard-codes `/usr/share/mx-tools/locale`, so development builds can't be tested in other languages. Loading both `qt_` and `qtbase_` is redundant, because `qt_` is a meta catalog that already includes qtbase.
    **Fix:** consider embedding the `.qm` files as resources (drop `QM_FILES_OUTPUT_VARIABLE` so `qt_add_translations` embeds them). This also removes the `.qm` lines from `debian/install` and `PKGBUILD`. Otherwise, fall back to a path relative to `applicationDirPath()`. Load only `qt_`.

## Tests

39. [x] **The code that changes user files has no tests.** `hideMenuEntries`, `restoreMenuEntries`, `restoreLegacyMenuEntries` and `replaceVisibilityLines` rewrite or delete files in the user's home directory, and none of them are tested. Add tests for:
    - (a) hide then restore with no prior override removes our file;
    - (b) a pre-existing user override is byte-identical after the round trip;
    - (c) edits the user makes while hidden are kept and the original visibility lines are restored;
    - (d) a legacy override is detected and removed, while a user's own `NoDisplay=true` override is left alone;
    - (e) a failure part-way through hiding rolls back.

    Stub xfconf-query with a fake script placed first in `PATH`, including a localized or stderr-noisy variant for items 1 and 2. `xfconfQueryAvailable()` caches its result in a static (`:206`), so make it injectable.

40. [x] **The launch test depends on timing.** `QTest::qWait(600)` for a 0.2 s sleep (`tests/test_toolmodel.cpp:146`) can flake on a loaded builder. `QVERIFY2` inside the `void` helper `writeDesktopFile` (`:24`) only returns from the helper, so the test carries on after a failed write.
    **Fix:** poll with `QTRY_*`. Have the helper return `bool`, or check `QTest::currentTestFailed()` after calling it.

41. [x] **Localization and search behavior are untested.** `translatedValue`, the `lang_COUNTRY` → `lang` fallback and English-name search in a translated session have no coverage. Add a case with `Name[de]=`/`Comment[de]=` under `QLocale::setDefault(QLocale::German)` that checks the displayed name and that the English name still matches in search.

## Structure / performance (low)

42. [x] **Startup does repeated file I/O.** The constructor scans `/usr/share/applications` recursively five times, once per category (`:486`, `:594`), and reads every `.desktop` file each time. For each matching file it calls `isLiveEnvironment()` twice (`:498`, `:613`), which is a `QStorageInfo` lookup, and `currentDesktops()` once.
    **Fix:** do a single pass: read and parse each file once, and compute live state and desktops once. Combined with item 9, this also fixes item 11.

43. [ ] **`ToolModel` has too many responsibilities.** In about 1000 lines it handles discovery, filtering, launching, opening docs, desktop-override management and xfconf integration. The static `openLocalOrReport(path, ToolModel *model, …)` (`:699`) is a symptom of this.
   **Validation — DESIGN SUGGESTION:** This is an architectural preference rather than a demonstrated defect. Splitting the class may help maintenance, but method count and a static helper taking a model pointer are not independently correctness failures.

    **Fix:** split out a `DesktopEntry` parser, a `MenuVisibilityManager` (with Whisker favorites) and the list/filter model. This makes item 39 testable without constructing a model. Make `openLocalOrReport` an ordinary private member.

44. [x] **The static `QIcon` outlives `QApplication`.** `fallbackIcon()` keeps the icon in a function-local static (`:656`), which is destroyed after `QApplication`. Qt advises against GUI objects outliving the application because of pixmap caches.
   **Validation — UNVERIFIED:** The static does outlive QApplication, but lifetime ordering alone does not demonstrate unsafe destruction for this QIcon and its actual theme/SVG engine. QIcon is not a QWidget, and a general warning about GUI objects/pixmap caches is insufficient to prove a crash here. Keep as a defensive lifetime suggestion unless a relevant Qt guarantee or shutdown reproduction establishes the defect.

    **Fix:** store the fallback icon in the `ToolIconProvider` or `ToolModel` instance.
