<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="he_IL">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="42"/>
        <location filename="../qml/Main.qml" line="130"/>
        <location filename="../qml/Main.qml" line="540"/>
        <source>MX Tools</source>
        <translation type="unfinished">הכלים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="137"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="202"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="158"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="215"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="225"/>
        <source>Manual</source>
        <translation type="unfinished">ידני</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="230"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="258"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="371"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="382"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="23"/>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="51"/>
        <source>Hide those tools from the system menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="12"/>
        <source>They&apos;ll still be available here in MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="337"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="339"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="346"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="347"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="356"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="397"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="405"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="408"/>
        <source>Use the whole window for tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="484"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="512"/>
        <source>About MX Tools</source>
        <translation type="unfinished">על אודות הכלים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="547"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="553"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="562"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="566"/>
        <source>License</source>
        <translation type="unfinished">רישיון</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="570"/>
        <source>Changelog</source>
        <translation type="unfinished">יומן שינויים</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="576"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">הכלים של MX</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">על יישום זה</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">על אודות…</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">סגירת היישום</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">סגירה</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">ידני</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">יישומי MX אלו חוסכים זמן ומאמץ עם משימות חשובות.</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">הסתרת כלים עצמאיים מהתפריט</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">חיפוש</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">על אודות הכלים של MX</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">גרסה:</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">כלי הגדרות ל־MX Linux</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">רישיון של %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">רישיון</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">יומן שינויים</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ביטול</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;סגירה</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="89"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="114"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="117"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="120"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="123"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="125"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="727"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="958"/>
        <location filename="../src/toolmodel.cpp" line="969"/>
        <location filename="../src/toolmodel.cpp" line="974"/>
        <location filename="../src/toolmodel.cpp" line="988"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="958"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="963"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="963"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="974"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="969"/>
        <location filename="../src/toolmodel.cpp" line="988"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1000"/>
        <location filename="../src/toolmodel.cpp" line="1024"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1006"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1011"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1024"/>
        <location filename="../src/toolmodel.cpp" line="1037"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1037"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1035"/>
        <source>Changelog</source>
        <translation type="unfinished">יומן שינויים</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1058"/>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <location filename="../src/toolmodel.cpp" line="1201"/>
        <location filename="../src/toolmodel.cpp" line="1206"/>
        <location filename="../src/toolmodel.cpp" line="1217"/>
        <location filename="../src/toolmodel.cpp" line="1237"/>
        <location filename="../src/toolmodel.cpp" line="1297"/>
        <location filename="../src/toolmodel.cpp" line="1336"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1058"/>
        <location filename="../src/toolmodel.cpp" line="1201"/>
        <location filename="../src/toolmodel.cpp" line="1206"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <location filename="../src/toolmodel.cpp" line="1217"/>
        <location filename="../src/toolmodel.cpp" line="1237"/>
        <location filename="../src/toolmodel.cpp" line="1297"/>
        <location filename="../src/toolmodel.cpp" line="1336"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
