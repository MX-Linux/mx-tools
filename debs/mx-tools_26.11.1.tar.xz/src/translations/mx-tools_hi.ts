<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="42"/>
        <location filename="../qml/Main.qml" line="132"/>
        <location filename="../qml/Main.qml" line="567"/>
        <source>MX Tools</source>
        <translation type="unfinished">MX साधन</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="139"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="204"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="160"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="217"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="227"/>
        <source>Manual</source>
        <translation type="unfinished">सहायता गाइड</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="232"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="260"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="379"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="392"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="389"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="23"/>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="51"/>
        <source>Hide those tools from the system menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="12"/>
        <source>They&apos;ll still be available here in MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="345"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="347"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="356"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="357"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="364"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="407"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="417"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="420"/>
        <source>Use the whole window for tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="510"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="539"/>
        <source>About MX Tools</source>
        <translation type="unfinished">MX साधनों के बारे में</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="574"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="580"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="589"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="593"/>
        <source>License</source>
        <translation type="unfinished">लाइसेंस</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="597"/>
        <source>Changelog</source>
        <translation type="unfinished">बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="603"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">MX साधन</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">बारे में...</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">अनुप्रयोग बंद करें</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">बंद करें</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">सहायता गाइड</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">ये MX अनुप्रयोग महत्वपूर्ण कार्यों के दौरान समय व प्रयास की बचत करते हैं।</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">मेन्यू में इकलौते साधनों को प्रदर्शित न करें</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">खोज</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">MX साधनों के बारे में</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">संस्करण :</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">MX लिनक्स हेतु विन्यास साधन</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 लाइसेंस</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">लाइसेंस</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">बदलाव सूची</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">रद्द करें</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">बंद करें (&amp;C)</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="130"/>
        <source>Unpin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="130"/>
        <source>Pin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="171"/>
        <source>Unpin tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="171"/>
        <source>Pin tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="98"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="115"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="118"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="121"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="124"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="126"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="754"/>
        <source>Pin setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="754"/>
        <source>Could not save pinned tools.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="766"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="993"/>
        <location filename="../src/toolmodel.cpp" line="1004"/>
        <location filename="../src/toolmodel.cpp" line="1009"/>
        <location filename="../src/toolmodel.cpp" line="1027"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="993"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="998"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="998"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1009"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1004"/>
        <location filename="../src/toolmodel.cpp" line="1027"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1039"/>
        <location filename="../src/toolmodel.cpp" line="1063"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1045"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1050"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1056"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1056"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1063"/>
        <location filename="../src/toolmodel.cpp" line="1076"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1076"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1074"/>
        <source>Changelog</source>
        <translation type="unfinished">बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1097"/>
        <location filename="../src/toolmodel.cpp" line="1105"/>
        <location filename="../src/toolmodel.cpp" line="1249"/>
        <location filename="../src/toolmodel.cpp" line="1254"/>
        <location filename="../src/toolmodel.cpp" line="1265"/>
        <location filename="../src/toolmodel.cpp" line="1285"/>
        <location filename="../src/toolmodel.cpp" line="1362"/>
        <location filename="../src/toolmodel.cpp" line="1401"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1097"/>
        <location filename="../src/toolmodel.cpp" line="1249"/>
        <location filename="../src/toolmodel.cpp" line="1254"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1105"/>
        <location filename="../src/toolmodel.cpp" line="1265"/>
        <location filename="../src/toolmodel.cpp" line="1285"/>
        <location filename="../src/toolmodel.cpp" line="1362"/>
        <location filename="../src/toolmodel.cpp" line="1401"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
