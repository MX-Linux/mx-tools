inline const QString VERSION {"26.05.4"};
