<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_HK">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="20"/>
        <location filename="../qml/Main.qml" line="90"/>
        <location filename="../qml/Main.qml" line="566"/>
        <source>MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="97"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="143"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="118"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="156"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="166"/>
        <source>Manual</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="175"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="207"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="374"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="389"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="386"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="250"/>
        <location filename="../qml/Main.qml" line="268"/>
        <location filename="../qml/Main.qml" line="500"/>
        <location filename="../qml/Main.qml" line="516"/>
        <source>Hide those tools from the system menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="257"/>
        <location filename="../qml/Main.qml" line="271"/>
        <location filename="../qml/Main.qml" line="506"/>
        <location filename="../qml/Main.qml" line="519"/>
        <source>They&apos;ll still be available here in MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="340"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="342"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="349"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="350"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="359"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="404"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="416"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="419"/>
        <source>Use the whole window for tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="484"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="533"/>
        <source>About MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="573"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="579"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="588"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="596"/>
        <source>License</source>
        <translation type="unfinished">授權條款</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="604"/>
        <source>Changelog</source>
        <translation type="unfinished">變更紀錄</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="614"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>About this application</source>
        <translation type="vanished">關於本程式</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">關於……</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">版本：</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">MX Linux 版權所有 (c)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">授權條款</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">變更紀錄</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">關閉（&amp;C）</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="84"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="92"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="95"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="98"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="101"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="103"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="482"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="670"/>
        <location filename="../src/toolmodel.cpp" line="684"/>
        <location filename="../src/toolmodel.cpp" line="693"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="670"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="675"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="675"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="684"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="693"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="702"/>
        <location filename="../src/toolmodel.cpp" line="726"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="708"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="713"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="719"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="719"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="726"/>
        <location filename="../src/toolmodel.cpp" line="732"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="732"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="735"/>
        <source>Changelog</source>
        <translation type="unfinished">變更紀錄</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="450"/>
        <location filename="../src/toolmodel.cpp" line="458"/>
        <location filename="../src/toolmodel.cpp" line="774"/>
        <location filename="../src/toolmodel.cpp" line="779"/>
        <location filename="../src/toolmodel.cpp" line="825"/>
        <location filename="../src/toolmodel.cpp" line="876"/>
        <location filename="../src/toolmodel.cpp" line="914"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="450"/>
        <location filename="../src/toolmodel.cpp" line="774"/>
        <location filename="../src/toolmodel.cpp" line="779"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="458"/>
        <location filename="../src/toolmodel.cpp" line="825"/>
        <location filename="../src/toolmodel.cpp" line="876"/>
        <location filename="../src/toolmodel.cpp" line="914"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
