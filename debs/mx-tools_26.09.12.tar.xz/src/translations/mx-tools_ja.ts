<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="42"/>
        <location filename="../qml/Main.qml" line="131"/>
        <location filename="../qml/Main.qml" line="541"/>
        <source>MX Tools</source>
        <translation type="unfinished">MX ツール</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="138"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="203"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="159"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="216"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="226"/>
        <source>Manual</source>
        <translation type="unfinished">マニュアル</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="231"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="259"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="372"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="383"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="380"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="23"/>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="51"/>
        <source>Hide those tools from the system menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="12"/>
        <source>They&apos;ll still be available here in MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="338"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="340"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="347"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="348"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="357"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="398"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="406"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="409"/>
        <source>Use the whole window for tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="485"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="513"/>
        <source>About MX Tools</source>
        <translation type="unfinished">MX ツールについて</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="548"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="554"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="563"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="567"/>
        <source>License</source>
        <translation type="unfinished">ライセンス</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="571"/>
        <source>Changelog</source>
        <translation type="unfinished">更新履歴</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="577"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">MX ツール</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">このアプリケーションについて</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">情報...</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">アプリの終了</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">閉じる</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">マニュアル</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">一連の MX ツールを使うと、大切な作業にかかる時間や労力が節約できます。</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">メニューに個々のツールを表示しない</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">検索</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">MX ツールについて</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">バージョン：</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">MX Linux 用の各種設定ツールです</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">Copyright (c) MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">%1 ライセンス</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">ライセンス</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">更新履歴</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">キャンセル</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">閉じる(&amp;C)</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="89"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="114"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="117"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="120"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="123"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="125"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="727"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="958"/>
        <location filename="../src/toolmodel.cpp" line="969"/>
        <location filename="../src/toolmodel.cpp" line="974"/>
        <location filename="../src/toolmodel.cpp" line="988"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="958"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="963"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="963"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="974"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="969"/>
        <location filename="../src/toolmodel.cpp" line="988"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1000"/>
        <location filename="../src/toolmodel.cpp" line="1024"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1006"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1011"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1024"/>
        <location filename="../src/toolmodel.cpp" line="1037"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1037"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1035"/>
        <source>Changelog</source>
        <translation type="unfinished">更新履歴</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1058"/>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <location filename="../src/toolmodel.cpp" line="1201"/>
        <location filename="../src/toolmodel.cpp" line="1206"/>
        <location filename="../src/toolmodel.cpp" line="1217"/>
        <location filename="../src/toolmodel.cpp" line="1237"/>
        <location filename="../src/toolmodel.cpp" line="1297"/>
        <location filename="../src/toolmodel.cpp" line="1336"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1058"/>
        <location filename="../src/toolmodel.cpp" line="1201"/>
        <location filename="../src/toolmodel.cpp" line="1206"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <location filename="../src/toolmodel.cpp" line="1217"/>
        <location filename="../src/toolmodel.cpp" line="1237"/>
        <location filename="../src/toolmodel.cpp" line="1297"/>
        <location filename="../src/toolmodel.cpp" line="1336"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
