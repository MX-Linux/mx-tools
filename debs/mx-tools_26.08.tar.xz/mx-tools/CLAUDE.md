# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MX Tools is a Qt6/C++20 Qt Quick (QML) dashboard application for configuration tools in MX Linux. It provides a GUI interface for discovering and launching MX system configuration utilities via their `.desktop` files.

## Build System and Commands

This project uses **CMake with Ninja** as the build system. A convenience script (`build.sh`) is provided for common build tasks.

### Quick Build (Recommended)

```bash
# Standard release build
./build.sh

# Debug build
./build.sh --debug

# Use clang compiler
./build.sh --clang

# Clean before building
./build.sh --clean
```

### Package Building

```bash
# Build Debian package
./build.sh --debian
# Creates .deb files in debs/ directory

# Build Arch Linux package
./build.sh --arch
# Creates .pkg.tar.zst in build/ directory
```

### Manual CMake Build

```bash
# Configure and build
mkdir -p build
cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel

# Install (requires appropriate permissions)
cmake --install build
```

Run a development build with `./build/mx-tools`. The program discovers launchers from `/usr/share/applications`, so meaningful manual testing requires an MX-like host or representative desktop files.

### Translation Updates

`qt6_add_translations` collects `translations/*.ts` (except `mx-tools_en_US.ts`) and generates compressed `.qm` catalogs during the build. After changing translatable strings, update the TS sources with the Qt Linguist/CMake translation target or `lupdate`, then rebuild so `lrelease` validates the catalogs. Do not hand-edit generated `.qm` files.

## Architecture and Code Structure

### Core Components

- **`src/main.cpp`**: Initializes `QApplication`, translations, the `QQmlApplicationEngine`, the `toolicons` image provider, and the initial `backend`/`version` QML properties.
- **`src/toolmodel.{cpp,h}`**: `ToolModel`, a `QAbstractListModel` that discovers MX `.desktop` files, filters them for the current desktop/live environment, launches tools, and manages per-user menu visibility overrides. Also contains `ToolIconProvider`.
- **`qml/Main.qml`**: Owns the application window, responsive layout, search/category controls, dialogs, and backend signal handling.
- **`qml/components/`**: Reusable controls — `ToolCard`, `CategoryButton`, `ModernSwitch`, `SecondaryButton`, `ThemeToolTip`.

### Key Architectural Patterns

- **Qt Quick / QML UI, C++ backend**: Presentation and state binding live in QML; filesystem and process-launch behavior live in C++ (`ToolModel`).
- **Category-based tool organization**: Tools are organized into categories and filtered based on environment.
- **Environment-aware filtering**: Filters tools based on desktop environment, `OnlyShowIn`/`NotShowIn`, and MX-specific `MX-OnlyLive`/`MX-OnlyInstalled` keys.
- **Embedded QML module**: `CMakeLists.txt` embeds QML files and `icons/logo.svg` into the `MxTools` QML module via `qt6_add_qml_module`; there is no standalone `.qrc` file. Add new QML files or embedded resources to that call.

## Coding & UI Conventions

- 4-space indentation, surrounding Qt style. C++ classes use PascalCase, methods/locals use camelCase.
- Preserve `[[nodiscard]]`, `const`, `QStringLiteral`, and `QLatin1String` usage where appropriate.
- When extending `ToolModel`, update roles, `roleNames()`, properties, and notification signals together with the QML delegate. Preserve model reset/change notifications so views refresh correctly.
- Menu visibility code writes user overrides under `~/.local/share/applications`; changes there must remain atomic and preserve existing user modifications.
- In QML, use Qt Quick Layouts rather than manual geometry, expose required delegate/component inputs with `required property`, and maintain keyboard focus and `Accessible` metadata. Derive colors from `SystemPalette` and the palette properties in `Main.qml` — don't hard-code a light- or dark-only scheme. Use `qsTr()` for QML UI text and `tr()` for C++ text.

## Configuration and Settings

### Compiler Settings (CMakeLists.txt)

- C++20 standard enabled (`CMAKE_CXX_STANDARD 20`)
- Strict compiler warnings with `-Werror` flags for critical issues (return-type, switch, uninitialized)
- Link-time optimization (LTO) enabled for release builds:
  - Clang uses `-flto=thin`
  - GCC uses `-flto=auto`
- Qt6 Core, Gui, Widgets, Qml, Quick, QuickControls2, and LinguistTools required
- Automatic MOC and RCC processing enabled (no `.ui` files / AUTOUIC)
- Colored compiler output for Ninja builds

### Translation System

- Qt Linguist (.ts files) for application translations
- Separate desktop file translations in `translations-desktop-file/`
- Supports extensive internationalization (50+ languages)
- Translations compiled to .qm files during build with optimizations:
  - `-compress`: Compress translation data
  - `-nounfinished`: Remove unfinished translations
  - `-removeidentical`: Remove translations identical to source text
  - `-silent`: Suppress verbose output

## Development Workflow

### Making Changes

1. C++ source is under `src/`; QML UI is under `qml/` (`Main.qml` and `qml/components/`).
2. Resources (icons, images) are embedded via `qt6_add_qml_module` in `CMakeLists.txt`, not a `.qrc` file.
3. Version information comes from `debian/changelog` and is set via `VERSION` define during build (override with `-DPROJECT_VERSION_OVERRIDE=<version>`).
4. Build artifacts go into `build/` directory (git-ignored).

### Testing and Validation

- No automated test framework is currently configured.
- Manual testing should focus on tool discovery/launching and UI functionality: startup, responsive wide and compact layouts, category filtering, search, condensed view, dialogs, themed icons in light/dark, and both X11 (`QT_QPA_PLATFORM=xcb`) and Wayland.
- Test on different desktop environments (KDE, XFCE, etc.), and check live-vs-installed exclusions and menu-visibility hide/restore behavior.

## Important Files

- `CMakeLists.txt`: CMake build configuration (embeds the QML module)
- `build.sh`: Convenience build script with multiple options
- `PKGBUILD`: Arch Linux package build script
- `src/main.cpp`: Application entry point, Qt6/QML setup, internationalization
- `src/toolmodel.{cpp,h}`: `ToolModel` and `ToolIconProvider`
- `qml/Main.qml`: Main application window/layout
- `qml/components/`: Reusable QML controls
- `debian/changelog`: Version source for builds
- `debian/rules`: Debian packaging rules with CMake+Ninja configuration
- `translations/*.ts`: Application translation files
- `translations-desktop-file/`: Desktop file translations
- `icons/`: Bundled/installed icons

## Version Management

Version information is extracted from `debian/changelog`:
- Build script parses the first line to determine version
- CMake uses `dpkg-parsechangelog` or manual parsing
- Version can be overridden with `PROJECT_VERSION_OVERRIDE` CMake variable
- For PKGBUILD, set `PKGVER` environment variable before building
