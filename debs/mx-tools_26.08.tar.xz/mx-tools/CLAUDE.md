# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MX Tools is a Qt6-based dashboard application for configuration tools in MX Linux. It provides a GUI interface for launching various system configuration utilities. The application uses a modern Qt6 architecture with C++20 standards.

## Build System and Commands

This project uses **CMake with Ninja** as the build system. A convenience script (`build.sh`) is provided for common build tasks.

### Quick Build (Recommended)

```bash
# Standard release build
./build.sh

# Debug build
./build.sh --debug

# Use clang compiler
./build.sh --clang

# Clean before building
./build.sh --clean
```

### Package Building

```bash
# Build Debian package
./build.sh --debian
# Creates .deb files in debs/ directory

# Build Arch Linux package
./build.sh --arch
# Creates .pkg.tar.zst in build/ directory
```

### Manual CMake Build

```bash
# Configure and build
mkdir -p build
cmake -G Ninja -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel

# Install (requires appropriate permissions)
cmake --install build
```

### Translation Updates

```bash
# Update translation source files from code
lupdate mx-tools.pro

# Translations are automatically compiled during CMake build
# Manual compilation (if needed):
qt6_lrelease translations/*.ts
```

## Architecture and Code Structure

### Core Components

- **MainWindow** (`mainwindow.cpp/h`): Primary application window and main logic
- **FlatButton** (`flatbutton.cpp/h`): Custom button widget for the dashboard interface
- **About** (`about.cpp/h`): About dialog functionality
- **main.cpp**: Application entry point with Qt6 setup and internationalization

### Key Architectural Patterns

- **QDialog-based main window**: Inherits from QDialog rather than QMainWindow
- **Category-based tool organization**: Tools are organized into categories and filtered based on environment
- **Multi-map data structure**: Uses QMultiMap for organizing tool categories
- **Environment-aware filtering**: Filters tools based on desktop environment and live/installed status

### UI Framework

- Built with Qt6 widgets
- Uses .ui files for UI design (mainwindow.ui)
- Custom FlatButton widgets for dashboard interface
- Resource system for icons and images (images.qrc)

## Configuration and Settings

### Compiler Settings (CMakeLists.txt)

- C++20 standard enabled (`CMAKE_CXX_STANDARD 20`)
- Strict compiler warnings with `-Werror` flags for critical issues (return-type, switch, uninitialized)
- Link-time optimization (LTO) enabled for release builds:
  - Clang uses `-flto=thin`
  - GCC uses `-flto=auto`
- Qt6 Core, Gui, Widgets, and LinguistTools required
- Automatic MOC, UIC, and RCC processing enabled
- Colored compiler output for Ninja builds

### Translation System

- Qt Linguist (.ts files) for application translations
- Separate desktop file translations in `translations-desktop-file/`
- Supports extensive internationalization (50+ languages)
- Translations compiled to .qm files during build with optimizations:
  - `-compress`: Compress translation data
  - `-nounfinished`: Remove unfinished translations
  - `-removeidentical`: Remove translations identical to source text
  - `-silent`: Suppress verbose output

## Development Workflow

### Making Changes

1. Source files are in the root directory
2. UI files are `.ui` files edited with Qt Designer
3. Resources (icons, images) are managed through `images.qrc`
4. Version information comes from `debian/changelog` and is set via `VERSION` define during build
5. Build artifacts go into `build/` directory (git-ignored)

### Testing and Validation

- No automated test framework is currently configured
- Manual testing should focus on tool launching and UI functionality
- Test on different desktop environments (KDE, XFCE, etc.)

## Important Files

- `CMakeLists.txt`: CMake build configuration
- `build.sh`: Convenience build script with multiple options
- `PKGBUILD`: Arch Linux package build script
- `mainwindow.{cpp,h,ui}`: Main window implementation and design
- `flatbutton.{cpp,h}`: Custom button widget for dashboard
- `debian/changelog`: Version source for builds
- `debian/rules`: Debian packaging rules with CMake+Ninja configuration
- `translations/*.ts`: Application translation files
- `translations-desktop-file/`: Desktop file translations
- `images.qrc`: Qt resource file for icons and images

## Version Management

Version information is extracted from `debian/changelog`:
- Build script parses the first line to determine version
- CMake uses `dpkg-parsechangelog` or manual parsing
- Version can be overridden with `PROJECT_VERSION_OVERRIDE` CMake variable
- For PKGBUILD, set `PKGVER` environment variable before building