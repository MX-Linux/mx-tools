Format: 3.0 (native)
Source: mx-tools
Binary: mx-tools
Architecture: any
Version: 26.08
Maintainer: Adrian <adrian@mxlinux.org>
Homepage: https://github.com/MX-Linux/mx-tools
Standards-Version: 4.5.1
Vcs-Git: git://github.com/MX-Linux/mx-tools
Build-Depends: debhelper-compat (= 12), cmake (>= 3.16), ninja-build, qt6-base-dev, qt6-base-dev-tools, qt6-declarative-dev, qt6-tools-dev, qt6-tools-dev-tools
Package-List:
 mx-tools deb admin optional arch=any
Checksums-Sha1:
 fefd21c47bf2cf69709a6a8df5b7db0ab02fedb6 16781284 mx-tools_26.08.tar.xz
Checksums-Sha256:
 36102cfab5970b7047393811314a35fc393bec3dcd7e17a683007056bb8414bd 16781284 mx-tools_26.08.tar.xz
Files:
 4887b52bd34edba75319cbd62df0d228 16781284 mx-tools_26.08.tar.xz
