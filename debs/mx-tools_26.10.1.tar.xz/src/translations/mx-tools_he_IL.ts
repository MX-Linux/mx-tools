<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="he_IL">
<context>
    <name>Main</name>
    <message>
        <location filename="../qml/Main.qml" line="42"/>
        <location filename="../qml/Main.qml" line="131"/>
        <location filename="../qml/Main.qml" line="552"/>
        <source>MX Tools</source>
        <translation type="unfinished">הכלים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="138"/>
        <source>System dashboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="203"/>
        <source>Search tools and tasks…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="159"/>
        <source>Search tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="216"/>
        <source>Clear search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="226"/>
        <source>Manual</source>
        <translation type="unfinished">ידני</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="231"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="259"/>
        <source>CATEGORIES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="378"/>
        <source>Condensed view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="391"/>
        <source>Show more tools at once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="388"/>
        <source>Use condensed tool view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="23"/>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="51"/>
        <source>Hide those tools from the system menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/MenuVisibilityToggle.qml" line="12"/>
        <source>They&apos;ll still be available here in MX Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="344"/>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="346"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="355"/>
        <source>Results matching “%1”</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="356"/>
        <source>Choose a tool to configure or maintain your system</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../qml/Main.qml" line="363"/>
        <source>%n tool(s)</source>
        <translation type="unfinished">
            <numerusform></numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="406"/>
        <source>Hide categories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="416"/>
        <source>Hide the category list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="419"/>
        <source>Use the whole window for tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="496"/>
        <source>No tools found
Try a different search or category.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="524"/>
        <source>About MX Tools</source>
        <translation type="unfinished">על אודות הכלים של MX</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="559"/>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="565"/>
        <source>A focused collection of configuration and maintenance tools for MX Linux.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="574"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="578"/>
        <source>License</source>
        <translation type="unfinished">רישיון</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="582"/>
        <source>Changelog</source>
        <translation type="unfinished">יומן שינויים</translation>
    </message>
    <message>
        <location filename="../qml/Main.qml" line="588"/>
        <source>Copyright © MX Linux</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>MX Tools</source>
        <translation type="vanished">הכלים של MX</translation>
    </message>
    <message>
        <source>About this application</source>
        <translation type="vanished">על יישום זה</translation>
    </message>
    <message>
        <source>About...</source>
        <translation type="vanished">על אודות…</translation>
    </message>
    <message>
        <source>Alt+B</source>
        <translation type="vanished">Alt+B</translation>
    </message>
    <message>
        <source>Close application</source>
        <translation type="vanished">סגירת היישום</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">סגירה</translation>
    </message>
    <message>
        <source>Alt+N</source>
        <translation type="vanished">Alt+N</translation>
    </message>
    <message>
        <source>Manual</source>
        <translation type="vanished">ידני</translation>
    </message>
    <message>
        <source>These MX applications save time and effort with important tasks.</source>
        <translation type="vanished">יישומי MX אלו חוסכים זמן ומאמץ עם משימות חשובות.</translation>
    </message>
    <message>
        <source>Hide individual tools from the menu</source>
        <translation type="vanished">הסתרת כלים עצמאיים מהתפריט</translation>
    </message>
    <message>
        <source>search</source>
        <translation type="vanished">חיפוש</translation>
    </message>
    <message>
        <source>About MX Tools</source>
        <translation type="vanished">על אודות הכלים של MX</translation>
    </message>
    <message>
        <source>Version: </source>
        <translation type="vanished">גרסה:</translation>
    </message>
    <message>
        <source>Configuration Tools for MX Linux</source>
        <translation type="vanished">כלי הגדרות ל־MX Linux</translation>
    </message>
    <message>
        <source>Copyright (c) MX Linux</source>
        <translation type="vanished">זכויות היוצרים (c) שמורות ל־MX Linux</translation>
    </message>
    <message>
        <source>%1 License</source>
        <translation type="vanished">רישיון של %1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>License</source>
        <translation type="vanished">רישיון</translation>
    </message>
    <message>
        <source>Changelog</source>
        <translation type="vanished">יומן שינויים</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ביטול</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="vanished">&amp;סגירה</translation>
    </message>
</context>
<context>
    <name>ToolCard</name>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="130"/>
        <source>Unpin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="130"/>
        <source>Pin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="171"/>
        <source>Unpin tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="171"/>
        <source>Pin tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qml/components/ToolCard.qml" line="98"/>
        <source>Open this MX tool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolModel</name>
    <message>
        <location filename="../src/toolmodel.cpp" line="114"/>
        <source>Live</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="117"/>
        <source>Maintenance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="120"/>
        <source>Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="123"/>
        <source>Software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="125"/>
        <source>Utilities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="749"/>
        <source>Pin setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="749"/>
        <source>Could not save pinned tools.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="761"/>
        <source>All tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="987"/>
        <location filename="../src/toolmodel.cpp" line="998"/>
        <location filename="../src/toolmodel.cpp" line="1003"/>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Unable to launch tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="987"/>
        <source>The selected tool is no longer available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="992"/>
        <source>Tool already running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="992"/>
        <source>%1 is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1003"/>
        <source>The selected tool has no launch command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="998"/>
        <location filename="../src/toolmodel.cpp" line="1017"/>
        <source>Could not start %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1029"/>
        <location filename="../src/toolmodel.cpp" line="1053"/>
        <source>Could not open %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1035"/>
        <source>Manual unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1040"/>
        <source>License unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1046"/>
        <source>Website unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1046"/>
        <source>Could not open the MX Linux website.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1053"/>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <source>Changelog unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1066"/>
        <source>Could not read the application changelog.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1064"/>
        <source>Changelog</source>
        <translation type="unfinished">יומן שינויים</translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1087"/>
        <location filename="../src/toolmodel.cpp" line="1095"/>
        <location filename="../src/toolmodel.cpp" line="1230"/>
        <location filename="../src/toolmodel.cpp" line="1235"/>
        <location filename="../src/toolmodel.cpp" line="1246"/>
        <location filename="../src/toolmodel.cpp" line="1266"/>
        <location filename="../src/toolmodel.cpp" line="1326"/>
        <location filename="../src/toolmodel.cpp" line="1365"/>
        <source>Menu setting failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1087"/>
        <location filename="../src/toolmodel.cpp" line="1230"/>
        <location filename="../src/toolmodel.cpp" line="1235"/>
        <source>Could not create %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/toolmodel.cpp" line="1095"/>
        <location filename="../src/toolmodel.cpp" line="1246"/>
        <location filename="../src/toolmodel.cpp" line="1266"/>
        <location filename="../src/toolmodel.cpp" line="1326"/>
        <location filename="../src/toolmodel.cpp" line="1365"/>
        <source>Could not update %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
