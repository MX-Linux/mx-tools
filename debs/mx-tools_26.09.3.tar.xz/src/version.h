inline const QString VERSION {"26.09.3"};
